
window.WE_CONFIG = {
  AR1_VIDEO_URL: "https://firebasestorage.googleapis.com/v0/b/sorigaden.firebasestorage.app/o/we%2Far%2F1.mp4?alt=media&token=0c289a1d-0346-4c63-a08f-996d94f86dc2",
  AR2_VIDEO_URL: "https://firebasestorage.googleapis.com/v0/b/sorigaden.firebasestorage.app/o/we%2Far%2F2.mp4?alt=media&token=866679ed-8850-44a8-b82e-f73e3e60b128",
  AR1_MARKER_PNG_URL: "https://firebasestorage.googleapis.com/v0/b/sorigaden.firebasestorage.app/o/we%2Far%2F1.png?alt=media&token=d4d75cc8-9e41-46d9-ba65-3958fcba39e9",
  AR2_MARKER_PNG_URL: "https://firebasestorage.googleapis.com/v0/b/sorigaden.firebasestorage.app/o/we%2Far%2F2.png?alt=media&token=b4b91f9b-fd39-460c-9a61-e1eed5f36d1a",
  NFC1_VIDEO_URL: "https://firebasestorage.googleapis.com/v0/b/sorigaden.firebasestorage.app/o/we%2Fnfc%2Fnfc1.mp4?alt=media&token=036341fb-af8d-4458-8980-5683546f1d06"
};
