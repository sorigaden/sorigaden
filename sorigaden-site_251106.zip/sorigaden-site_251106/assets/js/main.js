// global scripts
